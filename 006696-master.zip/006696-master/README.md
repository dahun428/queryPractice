# 006696
<p>오라클 SQL과 PL/SQL을 다루는 기술
<a href="http://www.yes24.com/24/Goods/18077084?Acode=101" target="_blank">▶ 서점에서 보기 Click! ◀</a></p>
